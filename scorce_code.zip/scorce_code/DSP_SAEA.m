format compact;
clear all;
t1=clock;
for ifu = 1:4
    clearvars -except ifu;
    for l = 1:31
        clearvars -except data l t t1 ifu;
        t1=clock;
        %% ��ʼ��
        warning('off')
        iterl = 100;
        c = 10;
        nl = 5*c;
        npl = 50;
        np = 50;
        termination = 11*c;
        N = 5*c;
        if ifu==1
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%_____1.���庯��Ellipsoid
            name=@Ellipsoid;
            global bu bd
            bu=5.12;
            bd=-5.12;
            vmax=5.12;
            vmin=-5.12;
        end
        if ifu==2
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%_____2.��庯��Rosenbrock
            name=@Rosenbrock;
            global bu bd
            bu=2.048;
            bd=-2.048;
            vmax=2.048;
            vmin=-2.048;
        end
        if ifu==3
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%_____4.��庯��Ackley
            name=@Ackley;
            global  bu bd
            bu=32.768;
            bd=-32.768;
            vmax=32.768;
            vmin=-32.768;
        end
        if ifu==4
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%_____3.��庯��Griewank
            name=@Griewank;
            global bu bd
            bu=600;
            bd=-600;
            vmax=600;
            vmin=-600;
        end
        BU = repmat(bu,1,c);
        BD = repmat(bd,1,c);
        [ POP ] = initialize_pop(N,c,bu,bd);
        obj = feval(name,POP);
        Data = [POP,obj];
        StepNext = 1;
        a0 = 0;
        v=(2*rand(np,c)-1).*(ones(np,1)*(vmax-vmin))*0.5;
        while size(Data,1)< termination
            StepCur = StepNext;
            switch StepCur
                case 1
                    %% ѡȡ�����Ժõĵ����ȫ�ֽ�ģ
                    Pg = sortrows(Data,c+1);%%��Ӧ��ֵ��С��������
                    DataG = Pg;
                    DataG = unique(DataG,'rows');
                    %% ����ȫ�ָ�˹ģ�ͽ�������
                    'Start Global Serch'
                    [gbest] = CSO_GP(Data, DataG,BU,BD);
                case 2
                    %% ѡ��ĺ��ʵ�������оֲ���Ѱ
                    Pl = sortrows(Data,c+1);
                    Xbest = Pl(1,:);
                    bul = Xbest(:,1:c) + Rexcl;
                    bul(bul > bu) = bu;
                    bdl = Xbest(:,1:c) - Rexcl;
                    bdl(bdl < bd) = bd;
                    %% ѡȡ���ʵĵ㽨���ֲ�ģ��
                    Pl = unique(Pl,'rows');
                    D=Pl;
                    a111 = [];
                    for i = 1:size(D,1)
                        distance = sum(abs(Pl(:,1:c)-repmat(Pl(i,1:c),size(Pl,1),1)).^2,2).^(1/2);
                        a1111=find(distance < 0.001);
                        a1111(find(a1111==i)) = [];
                        a111=[a111;a1111];
                    end
                    Pl(a111,:) = [];
                    distance = sum(abs(Pl(:,1:c)-repmat(Xbest(:,1:c),size(Pl,1),1)).^2,2).^(1/2);
                    [a1, b]= sortrows(distance,1);
                    a11 = find(a1<Rexcl);
                    if size(Pl,1) < nl
                        Datal = Pl;
                    else if length(a11) < nl
                            Datal = Pl(b(1:nl),:);
                        else
                            Datal = Pl(a11,:);
                        end
                    end
                    %% �����ֲ�ģ�Ͷ�����оֲ�����
                    'Start Local Serch'
                    [gbestxf, gbestf, gbest] = CSO_LRA(Datal,bul,bdl,npl,iterl,Xbest);
            end
            switch StepCur
                case 1
                    if ~isempty(gbest)
                        gbest(:,c+1) = feval(name,gbest(:,1:c));
                        t = gbest;
                        Data=[Data;gbest(:,1:c+1)];
                        StepNext =  2;   % swith local
                    end
                    D1 = sortrows(Data,c+1);
                    if length(D1) < 5*c
                        D1 = D1;
                    else
                        D1 = D1(1:5*c,:);
                    end
                    [~,xmin]=min(D1(:,c+1));
                    Xmin=D1(xmin,:);
                    Xmin = Xmin(:,1:c);
                    [~,xmax]=max(D1(:,c+1));
                    Xmax=D1(xmax,:);
                    Xmax = Xmax(:,1:c);
                    Rexcl=norm(Xmin-Xmax)/2;
                case 2
                    if ~isempty(gbest) 
                        gbest(:,c+1) = feval(name,gbest(:,1:c));
                        t = gbest;
                        Data=[Data;gbest(:,1:c+1)];
                    end
                    a0 = a0 + 1;
                    if a0 < 7 %round(0.4*c)
                        StepNext=2;
                    else
                        a0 = 0;
                        StepNext = 1; % swith global
                    end
                    if ~isempty(gbest)
                        ro=(Xbest(:,c+1)-gbest(:,c+1))/(gbestxf - gbestf-10^(-20));
                        if norm(Xbest(:,1:c)-gbest(:,1:c)) < Rexcl
                            es=1;
                        end
                        if norm(Xbest(:,1:c)-gbest(:,1:c)) >= Rexcl
                            es=2;
                        end
                        if ro<0.25
                            Rexcl=0.25*Rexcl;
                        end
                        if ro>0.75
                            Rexcl=es*Rexcl;
                        end
                        if ro>=0.25&&ro<=0.75
                            Rexcl=Rexcl;
                        end
                    else
                        Rexcl=Rexcl;
                    end
            end
            if ~isempty(gbest)
                min(Data(:,c+1))
                size(Data,1)
            end
        end
        t2=clock;
        etime(t2,t1)
        data{l} = Data;
    end
    if ifu == 1
        save F1 data
    end
    if ifu == 2
        save F2 data
    end
    if ifu == 3
        save F3 data
    end
    if ifu == 4
        save F4 data
    end
end