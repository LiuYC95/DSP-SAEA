function p= KmeanSelect( Data,n,c)
p = [];
P = Data(:,1:c);
[Idx,C]=kmeans(P,n);
for i = 1: n
    Id = find(Idx == i);
    if size(Id,1) == 1
        p = [p;Data(Id,:)];
    else
        c = (P(Id,:) - repmat(C(i,:),size(Id,2),1)).^2;
        dis = sqrt(sum(c, 2));
        [~,b] = min(dis);
        p = [p;Data(Id(b),:)];
    end
    
end
end