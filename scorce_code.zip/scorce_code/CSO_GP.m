function [gbest] = CSO_GP(Data,DataG,BU,BD)
c = size(DataG,2)-1;
p1 = Data;
D = p1;
a111 = [];
for i = 1:size(D,1)
    distance = sum(abs(p1(:,1:c)-repmat(p1(i,1:c),size(p1,1),1)).^2,2).^(1/2);
    a1111=find(distance < 0.001);
    a1111(find(a1111==i)) = [];
    a111=[a111;a1111];
end
p1(a111,:) = [];
p1 = unique(p1,'rows');
x = p1(:,1:c);
y = p1(:,c+1);

fmin = min(Data(:,c+1));
kernal='cubic';

np = 5; 
x1 = Data(:,1:c);
[~,center]=kmeans(x1,np);

RADIU=RBFcirle(center)/2;
Seed = center;

for i = 1:np
    lb=(Seed(i,:)-RADIU(i))';
    ub=(Seed(i,:)+RADIU(i))';
    for j=1:c
        if lb(j,1)<BD(1)
            lb(j,1)=BD(1);
        end
        if ub(j,1)>BU(1)
            ub(j,1)=BU(1);
        end
    end
    DI=[];
    XI=[];
    YI=[];
    dlimit=0.01;
    sumMX = Data(:,1:c);
    sumMY = Data(:,c+1);
    d=pdist2(Seed(i,:),sumMX)';
    index=find(d>dlimit);
    XI=sumMX(index,:);
    YI=sumMY(index,:);
    DI=d(index,:);
    ModelX=[];YModelX=[];
    len=5*c;%%%%%%%%%%%%%%%%%%%%%%%%
    if size(DI,1)<len
        ModelX=XI;
        YModelX=YI;
    else
        [DI,POS]=sort(DI);
        XI=XI(POS,:);
        YI=YI(POS,:);
        tt=0;
        for j=1:c
            tt=tt+(XI(len,j)<ub(j)&&XI(len,j)>lb(j));
        end
        if tt<c
            ModelX=XI(1:len,:);
            YModelX=YI(1:len,:);
        else
            for k=len:size(XI,1)
                tt=0;
                for j=1:c
                    tt=tt+(XI(k,j)<ub(j)&&XI(k,j)>lb(j));
                end
                if tt<c
                    break;
                end
            end
            ModelX=XI(1:k,:);
            YModelX=YI(1:k,:);
        end
    end
    
    global coefC
    coefC=[];
    coefC=rbfcreate(ModelX',YModelX','RBFFunction', kernal);
    [Nap,fap(i)]=YCSO(@YCRBF,[lb,ub]);
    Seedtarget(i,:)=Nap;
end
p0 = Seedtarget;
p11 = p0;
p22 = fap';
gbest = [p11,p22];
end