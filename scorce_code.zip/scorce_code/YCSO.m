function [xbest,fbest] = YCSO(name,Range)
phi = 1;
c = size(Range,1);
BU = Range(:,2)';
BD = Range(:,1)';
npl = 50;
iterl=100;
v=(2*rand(npl,c)-1).*(ones(npl,1)*(BU-BD))*0.5;
p = initialize_pop(npl,c,BU,BD);
fitness1 = feval(name,p);
fitness = fitness1';
for j = 1 : iterl
    % generate random pairs
    rlist = randperm(npl);
    rpairs = [rlist(1:ceil(npl/2)); rlist(floor(npl/2) + 1:npl)]';
    % calculate the center position
    center = ones(ceil(npl/2),1)*mean(p);
    %     center = ones(ceil(npl/2),1)*center1;
    % do pairwise competitions
    mask = (fitness(rpairs(:,1)) > fitness(rpairs(:,2)));
    losers = mask.*rpairs(:,1) + ~mask.*rpairs(:,2);
    winners = ~mask.*rpairs(:,1) + mask.*rpairs(:,2);
    %random matrix
    randco1 = rand(ceil(npl/2), c);
    randco2 = rand(ceil(npl/2), c);
    randco3 = rand(ceil(npl/2), c);
    
    % losers learn from winners
    v(losers,:) = randco1.*v(losers,:) ...,
        + randco2.*(p(winners,:) - p(losers,:)) ...,
        + phi*randco3.*(center - p(losers,:));
    p(losers,:) = p(losers,:) + v(losers,:);
    % boundary control
    for i = 1:ceil(npl/2)
        p(losers(i),:) = max(p(losers(i),:), BD);
        p(losers(i),:) = min(p(losers(i),:), BU);
    end
    fitness1 = feval(name,p(losers,:));
    fitness(losers,:) = fitness1';
end
[~, b] = min (fitness);
xbest = p(b,:);
fbest = fitness(b,:);
end