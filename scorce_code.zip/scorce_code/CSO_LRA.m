function [gbestxf, gbestf, gbest] = CSO_LRA(Datal,BU,BD,npl,iterl,P)
phi = 1;
c = size(Datal,2)-1;
p = Datal;
p = sortrows(p,c+1);
nl = length(Datal);
p1 = KmeanSelect(Datal, round(0.8*nl), c); % training data
te = [];
for i = 1: round(0.8*nl)
    te = [te; find(Datal(:,c+1) == p1(i,c+1))];
end
test_data = Datal; % test data
test_data(te,:) = [];
    
p1 = unique(p1,'rows');
x = p1(:,1:c);
y = p1(:,c+1);

% kriging StepCur = 1;
srgtOPTKRG  = srgtsKRGSetOptions(x, y);
srgtSRGTKRG = srgtsKRGFit(srgtOPTKRG);
[PRESSRMS_KRG, eXV_KRG] = srgtsCrossValidation(srgtOPTKRG);

% polynomial response surface StepCur = 2;
srgtOPTPRS  = srgtsPRSSetOptions(x, y);
srgtSRGTPRS = srgtsPRSFit(srgtOPTPRS);
[PRESSRMS_PRS, eXV_PRS] = srgtsCrossValidation(srgtOPTPRS);

% radial basis function % StepCur = 3;
srgtOPTRBF  = srgtsRBFSetOptions(x, y);
srgtSRGTRBF = srgtsRBFFit(srgtOPTRBF);
[PRESSRMS_RBF, eXV_RBF] = srgtsCrossValidation(srgtOPTRBF);

% computing weights % StepCur = 4;
eXVMatrix = [eXV_KRG eXV_RBF eXV_PRS];
CMatrix   = srgtsWASComputeCMatrix(x, eXVMatrix);

srgtsOPTs   = {srgtOPTKRG  srgtOPTRBF  srgtOPTPRS};
srgtsSRGTs  = {srgtSRGTKRG srgtSRGTRBF srgtSRGTPRS};
WAS_Model   = 'OWSdiag';
WAS_Options = CMatrix;

srgtOPTWAS  = srgtsWASSetOptions(srgtsOPTs, srgtsSRGTs, WAS_Model, WAS_Options);
srgtSRGTWAS = srgtsWASFit(srgtOPTWAS);

[f1, ~] = srgtsKRGPredictor(test_data(:,1:c), srgtSRGTKRG);
[f2, ~] = srgtsPRSPredictor(test_data(:,1:c), x, srgtSRGTPRS);
f3    = srgtsRBFEvaluate(test_data(:,1:c), srgtSRGTRBF);
[f4, ~] = srgtsWASPredictor(test_data(:,1:c), srgtSRGTWAS);
error1 = sum((f1 - test_data(:,c+1)).^2);
error2 = sum((f2 - test_data(:,c+1)).^2);
error3 = sum((f3 - test_data(:,c+1)).^2);
error4 = sum((f4 - test_data(:,c+1)).^2);
error = [error1, error2, error3, error4];
[~, b] = min(error);
StepCur = b;
v=(2*rand(npl,c)-1).*(ones(npl,1)*(BU-BD))*0.5;
[ p ] = initialize_pop(npl,c,BU,BD);
switch StepCur
    case 1
        [fitness, ~]= srgtsKRGPredictor(p, srgtSRGTKRG);
    case 2
        [fitness, ~] = srgtsPRSPredictor(p, x, srgtSRGTPRS);
    case 3
        fitness    = srgtsRBFEvaluate(p, srgtSRGTRBF);
    case 4
        [fitness, ~] = srgtsWASPredictor(p, srgtSRGTWAS);
end
for j = 1 : iterl
    % generate random pairs
    rlist = randperm(npl);
    rpairs = [rlist(1:ceil(npl/2)); rlist(floor(npl/2) + 1:npl)]';
    % calculate the center position
    center = ones(ceil(npl/2),1)*mean(p);
    % do pairwise competitions
    mask = (fitness(rpairs(:,1)) > fitness(rpairs(:,2)));
    losers = mask.*rpairs(:,1) + ~mask.*rpairs(:,2);
    winners = ~mask.*rpairs(:,1) + mask.*rpairs(:,2);  
    %random matrix
    randco1 = rand(ceil(npl/2), c);
    randco2 = rand(ceil(npl/2), c);
    randco3 = rand(ceil(npl/2), c);
    
    % losers learn from winners
    v(losers,:) = randco1.*v(losers,:) ...,
        + randco2.*(p(winners,:) - p(losers,:)) ...,
        + phi*randco3.*(center - p(losers,:));
    p(losers,:) = p(losers,:) + v(losers,:);
    % boundary control
    for i = 1:ceil(npl/2)
        p(losers(i),:) = max(p(losers(i),:), BD);
        p(losers(i),:) = min(p(losers(i),:), BU);
    end
    switch StepCur
        case 1
            [fitness(losers,:),~]= srgtsKRGPredictor(p(losers,:), srgtSRGTKRG);
        case 2
            [fitness(losers,:), ~] = srgtsPRSPredictor(p(losers,:), x, srgtSRGTPRS);
        case 3
            fitness(losers,:)    = srgtsRBFEvaluate(p(losers,:), srgtSRGTRBF);
        case 4
            [fitness(losers,:), ~] = srgtsWASPredictor(p(losers,:), srgtSRGTWAS);
    end
end
[~, b] = min (fitness);
gbest = [p(b,:),fitness(b,:)];
gbestf = fitness(b,:);

switch StepCur
    case 1
        [gbestxf, ~]= srgtsKRGPredictor(P(:,1:c), srgtSRGTKRG);
    case 2
        [gbestxf, ~] = srgtsPRSPredictor(P(:,1:c), x, srgtSRGTPRS);
    case 3
        gbestxf    = srgtsRBFEvaluate(P(:,1:c), srgtSRGTRBF);
    case 4
        [gbestxf, ~] = srgtsWASPredictor(P(:,1:c), srgtSRGTWAS);
end
end